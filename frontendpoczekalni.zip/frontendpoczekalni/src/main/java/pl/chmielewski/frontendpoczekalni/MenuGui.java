package pl.chmielewski.frontendpoczekalni;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;

@Route
public class MenuGui extends VerticalLayout{
    private Button tworzenieStolu;
    private Button wyszukanieStolu;
    private Button ustawieniaKonta;

    public MenuGui() {
        tworzenieStolu = new Button("Create new board");
        wyszukanieStolu = new Button("Find Board");
        ustawieniaKonta=new Button("Settings");

        VerticalLayout layout1 = new VerticalLayout();
        layout1.setSizeFull();
        layout1.getStyle().set("border", "1px solid #9E9E9E");


        layout1.add(tworzenieStolu,wyszukanieStolu);
        layout1.setHorizontalComponentAlignment(Alignment.CENTER,
                wyszukanieStolu,tworzenieStolu);
        layout1.setJustifyContentMode(JustifyContentMode.CENTER);


        layout1.add(ustawieniaKonta);
        layout1.setHorizontalComponentAlignment(Alignment.END,
                ustawieniaKonta);
        layout1.setJustifyContentMode(JustifyContentMode.END);
        add(layout1);

    }
}