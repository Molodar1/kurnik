package pl.chmielewski.frontendpoczekalni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontendpoczekalniApplicationTests {

    @Test
    void contextLoads() {
    }

}
