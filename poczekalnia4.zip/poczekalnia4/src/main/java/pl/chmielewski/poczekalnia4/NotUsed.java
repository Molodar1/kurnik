package pl.chmielewski.poczekalnia4;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.data.provider.ListDataProvider;
import com.vaadin.flow.router.Route;
import pl.chmielewski.poczekalnia4.model.Board;

import java.util.ArrayList;
import java.util.List;

@Route
public class NotUsed extends VerticalLayout {

    List<Board> boardCreation = new ArrayList<>();


    public NotUsed() {
        Grid<Board> grid = new Grid<>(Board.class);

        grid.addComponentColumn(item -> createRemoveButton(grid, item))
                .setHeader("Add");

        grid.setSelectionMode(Grid.SelectionMode.NONE);
        add(grid);
    }

    private Button createRemoveButton(Grid<Board> grid, Board item) {
        @SuppressWarnings("unchecked")
        Button button = new Button("Add", clickEvent -> {
            ListDataProvider<Board> dataProvider = (ListDataProvider<Board>) grid
                    .getDataProvider();
            //dataProvider.getItems().remove(item);
            //dataProvider.refreshAll();
        });
        return button;
    }
}
