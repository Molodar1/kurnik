package pl.chmielewski.poczekalnia4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Poczekalnia4Application {

    public static void main(String[] args) {
        SpringApplication.run(Poczekalnia4Application.class, args);
    }

}
