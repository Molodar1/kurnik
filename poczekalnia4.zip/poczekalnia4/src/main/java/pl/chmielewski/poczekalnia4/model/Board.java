package pl.chmielewski.poczekalnia4.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Board {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Mode mode;
    private String boardCreator;

    public Board() {
    }

    public Board(String name, Mode mode, String boardCreator) {
        this.name = name;
        this.mode = mode;
        this.boardCreator = boardCreator;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Mode getMode() {
        return mode;
    }

    public void setMode(Mode mode) {
        this.mode = mode;
    }

    public String getBoardCreator() {
        return boardCreator;
    }

    public void setBoardCreator(String boardCreator) {
        this.boardCreator = boardCreator;
    }

    @Override
    public String toString() {
        return "Board{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", mode=" + mode +
                ", boardCreator=" + boardCreator +
                '}';
    }
}