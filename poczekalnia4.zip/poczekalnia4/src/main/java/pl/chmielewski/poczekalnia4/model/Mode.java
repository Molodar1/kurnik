package pl.chmielewski.poczekalnia4.model;

public enum Mode {
    Ranked,UnranckedPublic,UnrankedPrivate


}
