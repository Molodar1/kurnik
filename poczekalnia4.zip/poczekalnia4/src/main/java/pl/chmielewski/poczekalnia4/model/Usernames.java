package pl.chmielewski.poczekalnia4.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Usernames {

  @Id
  private String username;

  public Usernames(String username) {
    this.username = username;
  }

  public Usernames() {
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  @Override
  public String toString() {
    return username;
  }
}
