package pl.chmielewski.poczekalnia4.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import pl.chmielewski.poczekalnia4.model.Usernames;

import java.util.List;

public interface UserNameRepo extends JpaRepository<Usernames,String> {


    public List<Usernames> findByUsername(String username);

    @Query(nativeQuery=true,value="SELECT * from usernames")
    List<Usernames> getUserNames();

}
