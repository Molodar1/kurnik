package pl.chmielewski.poczekalnia4.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pl.chmielewski.poczekalnia4.model.User;

@Repository
public interface UserRepo extends JpaRepository<User,Long> {

//public List<User> findByUsername(String username);



}
