package pl.chmielewski.poczekalnia4.service;


import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import pl.chmielewski.poczekalnia4.model.Mode;
import pl.chmielewski.poczekalnia4.model.User;
import pl.chmielewski.poczekalnia4.model.Usernames;
import pl.chmielewski.poczekalnia4.repository.UserNameRepo;
import pl.chmielewski.poczekalnia4.repository.UserRepo;

import java.util.ArrayList;
import java.util.EnumSet;

@Component
public class InitClass {

    private UserRepo userRepo;
    private UserNameRepo userNameRepo;
private ArrayList<User> userList;
private ArrayList<Usernames> userNamesList;
private ArrayList<Mode> modeList;

    public InitClass(UserRepo userRepo,UserNameRepo userNameRepo) {this.userRepo = userRepo; this.userNameRepo=userNameRepo;}
    @EventListener(ApplicationReadyEvent.class)
    public void init(){
        userList=new ArrayList<User>();

        modeList= new ArrayList<Mode>(EnumSet.allOf(Mode.class));
        userNamesList=new ArrayList<>();

        User user1=new User("Chmielu","Chmielux@gmail.com","1111");
        User user2=new User("Marex","Marex@gmail.com","2222");
        User user3=new User("Justa","Justa@gmail.com","3333");
        User user4=new User("Kubix","Kubix@gmail.com","4444");
        Usernames name1=new Usernames(user1.getUsername());
        Usernames name2=new Usernames(user2.getUsername());
        Usernames name3=new Usernames(user3.getUsername());
        Usernames name4=new Usernames(user4.getUsername());


userList.add(user1);
userList.add(user2);
userList.add(user3);
userList.add(user4);
        userNamesList.add(name1);
        userNamesList.add(name2);
        userNamesList.add(name3);
        userNamesList.add(name4);


userRepo.save(user1);
userRepo.save(user2);
userRepo.save(user3);
userRepo.save(user4);
userNameRepo.save(name1);
userNameRepo.save(name2);
userNameRepo.save(name3);
userNameRepo.save(name4);
    }

    public ArrayList<User> getUserList() {
        return userList;
    }

    public void setUserList(ArrayList<User> userList) {
        this.userList = userList;
    }

    public ArrayList<Usernames> getUserNamesList() {
        return userNamesList;
    }

    public void setUserNamesList(ArrayList<Usernames> userNamesList) {
        this.userNamesList = userNamesList;
    }
}
