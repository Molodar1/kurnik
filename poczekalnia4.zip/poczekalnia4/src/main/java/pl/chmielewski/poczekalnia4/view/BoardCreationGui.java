package pl.chmielewski.poczekalnia4.view;


import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.listbox.ListBox;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import org.springframework.beans.factory.annotation.Autowired;
import pl.chmielewski.poczekalnia4.model.Mode;
import pl.chmielewski.poczekalnia4.model.Usernames;
import pl.chmielewski.poczekalnia4.repository.UserNameRepo;
import pl.chmielewski.poczekalnia4.repository.UserRepo;
import pl.chmielewski.poczekalnia4.service.InitClass;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.EnumSet;


@Route
@Transactional
public class BoardCreationGui extends VerticalLayout {


private TextField textFieldName;
private TextField textFieldAddToGame;
   private  ListBox<Mode> listBox = new ListBox<>();
   private  ListBox<Mode> listBoxFriends = new ListBox<>();
   private InitClass initClass;
private ArrayList<Mode> modeList;
private ArrayList<Usernames> removeList;
private Button addPlayer;
private Button removeButton;
private TextArea textAreaPlayers;
private UserRepo userRepo;
private UserNameRepo userNameRepo;

@Autowired
    public BoardCreationGui(InitClass initClass,UserRepo userRepo,UserNameRepo userNameRepo) {
        this.initClass = initClass;
        this.userRepo=userRepo;
        this.userNameRepo=userNameRepo;


        modeList= new ArrayList<Mode>(EnumSet.allOf(Mode.class));
        listBox.setItems(modeList);
Button addPlayer=new Button("Add player");
    Button startGame=new Button("Start Game!");

        textFieldName = new TextField("BoardName");
textFieldAddToGame=new TextField("Add player by nickname:");

    ComboBox<Usernames> comboBoxFriendList = new ComboBox<>("Click on friend to add.");
    removeList=initClass.getUserNamesList();
    comboBoxFriendList.setItems(removeList);

    textAreaPlayers=new TextArea("Players In Board:");
//        addPlayer.addClickListener(buttonClickEvent ->);
            textAreaPlayers.setValue(userNameRepo.getUserNames().toString());



    ComboBox<Usernames> comboBoxRemove = new ComboBox<>("Click on player to remove.");
   removeList=initClass.getUserNamesList();
    comboBoxRemove.setItems(removeList);
    //comboBoxRemove.addValueChangeListener(event -> {
//        if (event.getValue()!=null)
//        {
//            removeList.remove(userNameRepo.findByUsername(event.getValue()))
//        }
  //  });
    VerticalLayout layout1 = new VerticalLayout();
    layout1.setSizeFull();
    layout1.getStyle().set("border", "1px solid #9E9E9E");


    layout1.add(textFieldName,listBox,textAreaPlayers,textFieldAddToGame,addPlayer,comboBoxFriendList,comboBoxRemove,startGame);
    layout1.setHorizontalComponentAlignment(FlexComponent.Alignment.CENTER,
            textFieldName,listBox,textAreaPlayers);
    layout1.setJustifyContentMode(FlexComponent.JustifyContentMode.CENTER);
    layout1.setHorizontalComponentAlignment(Alignment.END,
            textFieldAddToGame,addPlayer,comboBoxFriendList,comboBoxRemove,startGame);
    layout1.setJustifyContentMode(JustifyContentMode.END);
        //add(textFieldName,listBox,textFieldAddToGame,addPlayer,comboBoxFriendList,textAreaPlayers,comboBoxRemove);
    add(layout1);
    }




}
