package pl.chmielewski.poczekalnia4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Poczekalnia4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
